// const task1 = (s, n) => {
//     return {
//         name: s,
//         age: n
//     }
// }

// // console.log(task1('Вася', 20))
// // console.log(task1('Петя', 30))

// const task2 = (a) => {
//     a.name = 'Вася'
//     return a
// }

// // console.log(task2({age: 20}))
// // console.log(task2({name: 'Петя', age: 30}))
// // console.log(task2({}))

// const task3 = (a) => {
//     return `${a.name} ${a.age}`
// }

// // console.log(task3({ age: 20 }))
// // console.log(task3({ name: 'Петя', age: 30 }))
// // console.log(task3({}))

// const task4 = (a, s) => {
//     a[s] = s.toUpperCase()
//     return a
// }

// // console.log(task4({age: 20}, 'name'))
// // console.log(task4({name: 'Вася', age: 30}, 'age'))
// // console.log(task4({}, '0'))

// const task5 = (a, s) => {
//     delete a.name
//     delete a[s]
//     return a
// }

// // console.log(task5({age: 20}, 'age'))
// // console.log(task5({name: 'Петя', age: 30}, 'age'))
// // console.log(task5({age: 20}, 'name'))

// const task6 = (a) => {
//     if (a.a > a.b) {
//         a.a += a.b
//     }
//     else {
//         a.a++
//         a.b++
//     }
//     return a
// }

// // console.log(task6({a: 20, b: 10}))
// // console.log(task6({a: 20, b: 30}))
// // console.log(task6({a: 20, b: 20}))

// const task7 = (a) => {
//     return Object.keys(a)
// }

// // console.log(task7({a: 20, b: 10, 0: 30}))
// // console.log(task7({name: 'Вася', age: 20}))
// // console.log(task7({}))

// const task8 = (a) => {
//     return Object.values(a)
// }

// // console.log(task8({a: 20, b: 10, 0: 30}))
// // console.log(task8({name: 'Вася', age: 20}))
// // console.log(task8({}))

// const task9 = (a, keys) => {
//     const result = Array(keys.length)
//     for (let i = 0; i < keys.length; i++) {
//         result[i] = a[keys[i]] !== undefined
//     }
//     return result
// }

// // console.log(task9({a: 20, b: 10, 0: 30}, ['b', 'x', '0']))
// // console.log(task9({name: 'Вася', age: 20}, ['age', 'age', 'name']))
// // console.log(task9({}, ['a', 'a', 'a']))

// const task10 = (n) => {
//     const result = {}
//     for (let i = 0; i < n; i++) {
//         result[i] = n
//     }
//     return result
// }

// // console.log(task10(0))
// // console.log(task10(1))
// // console.log(task10(3))

// const task11 = (n) => {
//     const result = {}
//     for (let i = 0; i < n; i++) {
//         const letter = String.fromCharCode(97 + i)
//         result[letter] = letter.charCodeAt(0)
//     }
//     return result
// }

// // console.log(task11(0))
// // console.log(task11(1))
// // console.log(task11(3))

// const task12 = (s) => {
//     const result = {}
//     for (let i = 0; i < s.length; i++) {
//         result[s[i]] = s[i].charCodeAt(0)
//     }
//     return result
// }

// console.log(task12(''))
// console.log(task12('z'))
// console.log(task12('test'))

const task7 = (s) => {
    const obj = {}
    for (const item of s) {
        obj[item] = item
    }
    console.log(Object.keys(obj))
}

// task7('')
// task7('abc')
// task7('test')

const task8 = (a) => {
    for (const key in a) {
        console.log(key, a[key])
    }
}

// task8({ name: 'Vasya', age: 20 })
// task8({ a: 10, b: 20, c: 30 })
// task8({})

const task9 = (a) => {
    for (const [key, item] of Object.entries(a)) {
        console.log(key, item)
    }
}

task9({ name: 'Vasya', age: 20 })
task9({ a: 10, b: 20, c: 30 })
task9({})

